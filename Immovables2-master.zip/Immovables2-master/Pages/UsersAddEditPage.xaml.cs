﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Immovables.Pages
{
    /// <summary>
    /// Логика взаимодействия для UsersAddEditPage.xaml
    /// </summary>
    public partial class UsersAddEditPage : Page
    {
        private User _currentperson = new User(); //экземпляр добавляемого пользователя
        public UsersAddEditPage(User selectedUser)
        {
            InitializeComponent();
            if (selectedUser != null)
                _currentperson = selectedUser;
            DataContext = _currentperson;
            cmbfltrRole.ItemsSource = RealtorEntities.GetContext().Roles.ToList();
            cmbfltrRole.SelectedValuePath = "IDRole";
            cmbfltrRole.DisplayMemberPath = "Role1";
        }

        private void Savebtn_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();// Объект для сообщение об ошибке
            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentperson.Login))
                error.AppendLine("Укажите Логин");
            if (string.IsNullOrWhiteSpace(_currentperson.Password))
                error.AppendLine("Укажите Пароль");
            if (string.IsNullOrWhiteSpace(cmbfltrRole.Text))
                error.AppendLine("Укажите Права");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentperson.IDUser == 0)
                RealtorEntities.GetContext().Users.Add(_currentperson);//Добавить в контекст
            try
            {

                RealtorEntities.GetContext().SaveChanges();// Сохранить изменения
                MessageBox.Show("Данные сохраненны");
                this.NavigationService.Navigate(new UsersPage());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void cmbfltrRole_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
